import { Component } from '@angular/core';

@Component({
  selector: 'stbui-notice',
  templateUrl: './notice.component.html',
  styleUrls: ['./notice.component.scss'],
})
export class NoticeComponent {

}
