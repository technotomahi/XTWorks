import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nvd3-charts',
  templateUrl: './nvd3-charts.component.html',
  styleUrls: ['./nvd3-charts.component.scss']
})
export class Nvd3ChartsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
