## marker-animate-unobtrusive TypeScript demo

Reference TypeScript project of using [marker-animate-unobtrusive](https://github.com/terikon/marker-animate-unobtrusive).

Based on angular2/seed.


### Usage
- run `npm install` to install dependencies
- run `npm start` to fire up dev server
- open browser to [`http://localhost:3000`](http://localhost:3000)

